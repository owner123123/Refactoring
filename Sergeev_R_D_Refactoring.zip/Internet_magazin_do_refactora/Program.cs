﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Internet_magazin_do_refactora
{
    internal class Program
    {
        public class UserService
        {
            private readonly SqlConnection _connection;

            public UserService(SqlConnection connection)
            {
                _connection=connection;
            }
            //Проблемный метод получаения пользвателей с их заказами
            public List<object> GetUsersWithOrders()
            {
                var result= new List<object>();
                //Уязвимость SQL иньекции
                var usersCmd= new SqlCommand ("SELECT * FREOM Users", _connection);
                var userReader=usersCmd.ExecuteReader();
                while (userReader.Read())
                {
                    var userid = userReader.GetString(0);
                    var userName = userReader.GetString(1);
                    var ordersCmd=new SqlCommand ($"SELECT * FROM Orders where UserId={userid}",_connection);
                    var ordersReader=ordersCmd.ExecuteReader();
                    var orders = new List<object>();
                    while (ordersReader.Read())
                    {
                        orders.Add(new { OrderId = ordersReader.GetInt32(0), Total = ordersReader.GetDecimal(2) });
                    }
                    ordersReader.Close();
                    result.Add(new
                    {
                        UserId = userid,
                        Name = userName,
                        Orders = orders
                    });
                }
                userReader.Close();
                return result;
            }
        }
        static void Main(string[] args)
        {
        }
    }
}
